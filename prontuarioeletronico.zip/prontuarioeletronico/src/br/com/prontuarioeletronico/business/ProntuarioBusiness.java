package br.com.prontuarioeletronico.business;

import br.com.prontuarioeletronico.business.interfaces.IProntuarioBusiness;

public class ProntuarioBusiness 
	implements IProntuarioBusiness {

	@Override
	public void iniciarAtendimento() {

	}

}
