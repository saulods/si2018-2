package br.com.prontuarioeletronico.repository;

import java.util.ArrayList;
import java.util.List;

import br.com.prontuarioeletronico.domain.Prontuario;

public class RepositoryFactory {
	
	private static List<Prontuario> bancoDadosFake = null;
					
	public static List<Prontuario> getInstanceProntuario() {
		if(bancoDadosFake==null) {
			new ArrayList<Prontuario>();
		}		
		return bancoDadosFake;
	}
}
