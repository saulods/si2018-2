package br.com.prontuarioeletronico.business.interfaces;

public interface IProntuarioBusiness {
	
	public void iniciarAtendimento();

}
